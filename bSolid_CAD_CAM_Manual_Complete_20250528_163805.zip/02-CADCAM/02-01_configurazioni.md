# 環境設定 CAD/CAM

設定ツールを表示するボタン：![設定アイコン](../../FIGURE/15-icone/b15b0007/settings_01_32.png)

---

* [統計値の管理](finestre/FinStatistiche.md)
* [ソフトウエアオプション](finestre/FinOpzioni.md)
* [作業環境の構成](finestre/FinDefAmbLav.md)

<details>
<summary>関連項目</summary>

* [グリッドを構成する](../02-Nozioni/PianoCostr.md#グリッドを構成する)
* [座標システム](../02-Nozioni/PianoCostr.md#座標システム)
</details>

---" 